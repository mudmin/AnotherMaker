If you would like to override any of the existing language keys that are in users/lang, you can do so by creating a file with the same name in this folder.

See the en-US.php example.

Additinally, if you want to create your own language keys and use them throughout your project you can add to the language array by just adding additional keys.
