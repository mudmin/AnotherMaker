<?php
die("Nothing to see here :)");
 ?>
