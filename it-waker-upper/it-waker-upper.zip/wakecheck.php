<?php
header('Content-Type: application/json');
require_once 'users/init.php';
$db = DB::getInstance();
$key = Input::get('key');
$owner = Input::get('owner');


$response = [];
$response['success'] = 0;
$response['wake'] = 0;
$q = $db->query("SELECT * FROM it_devices WHERE owner = ? AND device_key = ?",[$owner,$key]);
$c = $q->count();
if($c > 0){
	$d = $q->first();
	$response['success'] = 1;
	$response['wake'] = (int)$d->wake;
	$response['msg'] = 200;

	//process acknowledgement
	$ack = Input::get('ack');

	if($ack == true){
		logger($d->owner,"ACK_DEVICE","Acknowledged");
		$db->update('it_devices',$d->id,['wake'=>0,'last_ack'=>date("Y-m-d H:i:s")]);
	}

}else{
	$response['msg'] = 403;
}
// if( isset($_SERVER['HTTPS'] ) ) {
// 	$response['https'] = true;
// }else{
// 	$response['https'] = false;
// }
// logger(1,"apilog",json_encode($_POST));

echo json_encode($response);
