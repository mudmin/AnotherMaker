<?php
require_once 'users/init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
  die();
}
$devices = $db->query("SELECT * FROM it_devices WHERE owner = ?",[$user->data()->id])->results();
$guests = $db->query("SELECT * FROM it_users_match WHERE owner = ?",[$user->data()->id])->results();

//let's get a list of whose devices you can access
$access = [];
$access[] = $user->data()->id;
$yourAccess = $db->query("SELECT * FROM it_users_match WHERE guest = ?",[$user->data()->id])->results();
foreach($yourAccess as $y){
  if(!in_array($y->owner,$access)){
    $access[] = $y->owner;
  }
}

if(!empty($_POST)){
  $token = Input::get('csrf');
  if(!Token::check($token)){
    include($abs_us_root.$us_url_root.'usersc/scripts/token_error.php');
  }

  if(!empty($_POST['ringIt'])){
    $ring = Input::get('ringThis');
    $q = $db->query("SELECT * FROM it_devices WHERE id = ?",[$ring]);
    $c = $q->count();
    if($c < 1){
      Redirect::to('dashboard.php?err=That device does not exist anymore');
    }

    $f = $q->first();
    if(!in_array($f->owner,$access)){
      Redirect::to('dashboard.php?err=You do not have access to that device anymore');
    }else{
      $fields = array(
        'last_ring'=>date("Y-m-d H:i:s"),
        'wake'=>1,
      );
      $db->update("it_devices",$f->id,$fields);
      Redirect::to('dashboard.php?err=Ringing Device. Check back for acknowledgement that device received message.');
    }



  }


  $deviceid = Input::get('deviceid');
  if(is_numeric($deviceid)){
    $check = $db->query("SELECT * FROM it_devices WHERE id = ? AND owner = ?",[$deviceid,$user->data()->id])->count();
    if($check < 1){
      logger($user->data()->id,"Invalid Device","Tried to edit a device that was not theirs");
      Redirect::to('dashboard.php?err=This is not your device. This has been logged');
    }
  }

  if(!empty($_POST['updateDevice'])){
    $device = Input::get('device');
    if($device != ""){
      $db->update("it_devices",$deviceid,['device'=>$device]);
      Redirect::to('dashboard.php?err=Device+updated');
    }
  }


  if(!empty($_POST['addDevice'])){
    $newdevice = Input::get('newDevice');
    if($newdevice != ""){
      if(count($devices) >= $user->data()->devices_allowed){
        Redirect::to('dashboard.php?err=You are at your device limit');
      }
      $code = strtoupper(randomstring(12).uniqid());
      $code = substr(chunk_split($code,5,'-'),0,-1);
      $db->insert("it_devices",['device'=>$newdevice,'owner'=>$user->data()->id,'device_key'=>$code]);
      Redirect::to('dashboard.php?err=Device+added');
    }
  }

  if(!empty($_POST['deleteDevice'])){
    $db->query("DELETE FROM it_devices WHERE id = ?",[$deviceid]);
    Redirect::to('dashboard.php?err=Device+deleted');
  }

  if(!empty($_POST['deleteUser'])){
    $uid = Input::get('userid');
    $db->query("DELETE FROM it_users_match WHERE owner = ? AND guest = ?",[$user->data()->id,$uid]);
    Redirect::to('dashboard.php?err=User+deleted');
  }

  if(count($guests) < $user->data()->guests_allowed){
    if(!empty($_POST['addGuest'])){
      $email = Input::get('newGuest');
      $q = $db->query("SELECT * FROM users WHERE email = ?",[$email]);
      $c = $q->count();
      if($c < 1){
        Redirect::to('dashboard.php?err=Email not found');
      }
      $u = $q->first();
      $db->insert('it_users_match',['owner'=>$user->data()->id,'guest'=>$u->id]);
      if(hasPerm([2,3,4],$u->id)){
        Redirect::to("dashboard.php?err=User added to your account");
      }else{
        Redirect::to("dashboard.php?err=User added to your account, but their account has not been approved.");
      }
    }
  }
}



?>
<div class="row">
  <div class="col-12">
    <h1 class="text-center"><?=$settings->site_name?> Dashboard</h1>
    <br>
  </div>
</div>
<div class="row">
  <div class="col-12">
    <h2 class="text-center">Ring A Device</h2>
  </div>
</div>
<div class="row">
  <?php
  foreach($access as $a) {
    $dev = $db->query("SELECT * FROM it_devices WHERE owner = ?",[$a])->results();
    foreach($dev as $d){
      ?>
      <div class="col-4 card text-center" style="padding:20px;">
        <h5><strong><?php echouser($d->owner);?></strong></h5>
        <h3><?=$d->device?></h3>
        <form class="" action="" method="post">
          <input type="hidden" name="csrf" value="<?=Token::generate();?>">
          <input type="hidden" name="ringThis" class="form-control" value="<?=$d->id?>">
          <input type="submit" name="ringIt" value="Ring The Alarm" class="btn btn-danger btn-lg">
          <p class="text-center">
            <br>
            <strong>Last Triggered: </strong><?=$d->last_ring?><br>
            <strong>Last Acknowledged: </strong><?=$d->last_ack?><br>
          </p>
        </form>
      </div>

      <?php
    }
  }
  ?>
</div>
<br><br>
<?php if(hasPerm([2,3],$user->data()->id)){?>
  <div class="row">
    <div class="col-12 col-sm-6">
      <?php
      if(count($devices) < $user->data()->devices_allowed){ ?>
        <h3 class="text-center">Add a Device</h3>
        <h5 class="text-center">Just give it a name and we'll generate a key</h5>

        <form class="" action="" method="post">
          <div class="row">
            <div class="col-12 col-sm-6 offset-sm-3 input-group">
              <input type="hidden" name="csrf" placeholder="Give it a name" value="<?=Token::generate();?>">
              <input type="text" name="newDevice" class="form-control" value="">
              <input type="submit" name="addDevice" value="Add Device" class="btn btn-primary">
            </div>
          </div>
        </form>
      <?php } ?>
      <br>

      <h3 class="text-center">Your Devices</h3>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Device Name</th>
            <th>Wake?</th>
            <th>Key</th>
            <th>Update</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($devices as $d){?>
            <tr>
              <form class="" action="" method="post">
                <td><?=$d->id?></td>
                <td>
                  <input type="text" name="device" value="<?=$d->device?>">
                </td>
                <td><?php bin($d->wake);?></td>
                <td><?=$d->device_key?></td>
                <td>
                  <input type="hidden" name="csrf" value="<?=Token::generate();?>">
                  <input type="hidden" name="deviceid" value="<?=$d->id?>">
                  <input type="submit" name="updateDevice" class="btn btn-primary" value="Update">
                </td>
              </form>
              <form class="" action="" method="post" onsubmit="return confirm('Do you really want to delete this device?');">
                <td>
                  <input type="hidden" name="csrf" value="<?=Token::generate();?>">
                  <input type="hidden" name="deviceid" value="<?=$d->id?>">
                  <input type="submit" name="deleteDevice" value="Delete" class="btn btn-danger">
                </td>
              </form>
            </tr>

          <?php } ?>
        </tbody>
      </table>
    </div>

    <div class="col-12 col-sm-6">
      <?php
      if(count($guests) < $user->data()->guests_allowed){ ?>
        <h3 class="text-center">Add a Guest</h3>
        <h5 class="text-center">User must already be registered on the system</h5>

        <form class="" action="" method="post">
          <div class="row">
            <div class="col-12 col-sm-6 offset-sm-3 input-group">
              <input type="hidden" name="csrf" value="<?=Token::generate();?>">
              <input type="text" name="newGuest" class="form-control" value="" placeholder="Email">
              <input type="submit" name="addGuest" value="Add Guest" class="btn btn-primary">
            </div>
          </div>
        </form>
      <?php } ?>
      <br>
      <h3 class="text-center">Your Guests</h3>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>User</th>
            <th>Approved?</th>
            <th>Delete</th>
          </tr>
        </thead>
        <?php foreach($guests as $g){ ?>
          <tr>
            <td><?php echouser($g->guest)?></td>
            <td><?php bin(hasPerm([2,3,4],$g->id));?></td>
            <form class="" action="" method="post" onsubmit="return confirm('Do you really want to delete this user?');">
              <td>
                <input type="hidden" name="csrf" value="<?=Token::generate();?>">
                <input type="hidden" name="userid" value="<?=$g->guest?>">
                <input type="submit" name="deleteUser" value="Delete" class="btn btn-danger">
              </td>
            </form>
          </tr>
        <?php } ?>
      </table>
    </div>
  </div>
<?php } ?>

<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>
